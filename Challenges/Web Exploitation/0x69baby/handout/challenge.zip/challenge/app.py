from flask import *
from functools import wraps
from Crypto.Util.Padding import pad, unpad
import os
from secret import FLAG
import sqlite3
from hashlib import md5



def get_db_connection():
    conn = sqlite3.connect('bhlous.db')
    conn.row_factory = sqlite3.Row
    return conn

app = Flask(__name__)

KEY = os.urandom(16) 

def parse_token(token):
    values = dict()
    for part in token.split("|"):
        key, value = part.split("=")
        values[key] = value
    return values

def generate_token(values):
    token = "|".join(f"{key}={value}" for key, value in values.items())
    return token

def get_sig(token : str):
    return md5(KEY + token).hexdigest()
    


def token_required(role= None):
    def decorator(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            token = bytes.fromhex(request.cookies.get('token'))
            sig = request.cookies.get('sig')
            if not sig or not token:
                return "<h1>Unauthorized access! Please log in.</h1>"
            try:
                calculated_sig = get_sig(token)
                print(token)
                print(sig)
                print(calculated_sig)
                if calculated_sig != sig:
                    return "<h1>Unauthorized access! Invalid signature.</h1>"
                decrypted = parse_token(token.decode('latin1'))
                if 'username' not in decrypted or 'role' not in decrypted and 'password' not in decrypted:
                    return "<h1>Unauthorized access! Invalid token.</h1>"
                
                g.user = decrypted['username']
                g.password = decrypted['password']
                g.role = decrypted['role']
                if len(role) == 2 and g.role not in role:
                    return "<h1>Unauthorized access! Users only.</h1>"
                elif role == 'admin' and g.role == role:
                    conn = get_db_connection()
                    c = conn.cursor()
                    query = f"SELECT password FROM users WHERE username='admin'"
                    c.execute(query)
                    password = c.fetchone()['password']
                    conn.close()
                    print(password)
                    print(decrypted)
                    if password != g.password:
                        return "<h1>Unauthorized access! Admins only.</h1>"
            except Exception as e:
                return "<h1>Invalid token! Please log in.</h1>"
            return f(*args, **kwargs)
        return wrapped
    return decorator

@app.route('/')
def home():
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']

        if not username or not password or not email:
            return render_template('signup.html')

        conn = get_db_connection()
        c = conn.cursor()
        c.execute('SELECT * FROM users WHERE username = ?', (username,))
        existing_user = c.fetchone()

        if existing_user:
            conn.close()
            return render_template('signup.html')

        try:
            c.execute('INSERT INTO users (username, password, email) VALUES (?, ?, ?)', 
                      (username, password, email))
            conn.commit()
            return redirect(url_for('login'))
        except sqlite3.Error as e:
            return '<h1>Error</h1>'
        finally:
            conn.close()

    return render_template('signup.html')

@app.route('/login', methods=['POST' , 'GET'])
def login():
    if request.method == 'GET':
        return render_template('login.html')
    username = request.form['username']
    password= request.form['password']
    if username == "admin":
        return "<h1>Unauthorized access! You can't login as admin.</h1>" , 403
    conn = get_db_connection()
    c = conn.cursor()
    c.execute('SELECT * FROM users WHERE username = ? AND password = ?', (username, password))
    user = c.fetchone()
    conn.close()
        
    if user:
        token = generate_token({
            'username': username,
            'password': password,
            'role': 'admin' if username == 'admin' else 'user',
        })
        signature = get_sig(token.encode())
        token = token.encode().hex()
        resp = make_response(redirect(url_for('find_friends')))
        resp.set_cookie('token', token)
        resp.set_cookie('sig', signature)
        return resp
    else:
        return render_template('login.html')

@app.route('/find_friends', methods=['GET', 'POST'])
@token_required(role=['user', 'admin'])
def find_friends():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        if not username:
            return render_template('find_friends.html', results=None)

        conn = get_db_connection()
        c = conn.cursor()
        query = f"SELECT username FROM users WHERE username LIKE '%{username}%'"
        try:
            c.execute(query)
            results = c.fetchall()
            conn.close()
            if results:
                return '<h1>Your Friend Exists!</h1>'
            
            else:
                return '<h1>Your Friend Dosent Exists!</h1>'
            
        except sqlite3.Error as e:
            return '<h1>Error</h1>'
        

    return render_template('find_friends.html', results=None)



@app.route('/dashboard')
@token_required()
def dashboard():
    return f"<h1>Welcome to your dashboard, {g.user}! Your role is: {g.role}.</h1>"

@app.route('/admin')
@token_required(role='admin')
def admin():
    return "<h1>Welcome to the admin page!</h1>\n" + FLAG

@app.route('/logout')
def logout():
    resp = make_response("<h1>You have been logged out.</h1>")
    resp.delete_cookie('token')
    return resp

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=6200)