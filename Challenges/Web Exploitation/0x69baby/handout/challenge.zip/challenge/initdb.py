import sqlite3


def init_db():
    conn = sqlite3.connect('bhlous.db')
    c = conn.cursor()

    
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            email TEXT NOT NULL
        )
    ''')


    
    admin_password = 'REDACTED'
    c.execute('INSERT OR IGNORE INTO users (username, password, email) VALUES (?, ?, ?)', ('admin', admin_password, 'admin@example.com'))

        
    conn.commit()
    conn.close()


if __name__ == "__main__":
    init_db()
    print("Database initialized successfully.")