// app/api/admin/flag/route.ts

import { NextRequest, NextResponse } from "next/server";
import jwt, { JwtPayload } from "jsonwebtoken";

export async function GET(req: NextRequest) {
  const token = req.cookies.get("auth")?.value;
  const headerOverride = req.headers.get("x-trusted-user");
  const userAgent = req.headers.get("user-agent") || "";
  const internalHeader = req.headers.get("x-internal-access");
  const fromPuppeteer = req.headers.get("x-from-puppeteer") === "true";

  const isHeadless =
    userAgent.toLowerCase().includes("headless") || userAgent.includes("puppeteer");

  // ❌ Block non-internal requests
  if (
    internalHeader !== "[REDACTED_SECRET]" ||
    !isHeadless ||
    headerOverride !== "admin"
  ) {
    return new NextResponse(
      `<html><body><div id="admin-panel" data-content="[REDACTED_FAKE_FLAG]"></div></body></html>`,
      { status: 200, headers: { "Content-Type": "text/html" } }
    );
  }

  try {
    const data = jwt.verify(token || "", "[REDACTED_SECRET]") as JwtPayload;

    const issuedAt = data.ts;
    const now = Date.now();

    if (!issuedAt || now - issuedAt > 30 * 1000) {
      return NextResponse.json({ error: "Token expired" }, { status: 403 });
    }

    if (data.name === "admin") {
      const html = `
        <html>
          <body>
            <div id="admin-panel" data-content="[REDACTED_FLAG]"></div>
          </body>
        </html>
      `;
      return new NextResponse(html, {
        status: 200,
        headers: { "Content-Type": "text/html" }
      });
    }

    return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
  }
}
