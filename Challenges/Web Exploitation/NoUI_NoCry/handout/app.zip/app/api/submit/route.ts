// app/api/submit/route.ts

import { NextRequest, NextResponse } from "next/server";
import jwt from "jsonwebtoken";
import puppeteer from "puppeteer";

export async function POST(req: NextRequest) {
  const { name, theme } = await req.json();

  // Generate a JWT for the user (stored in response)
  const token = jwt.sign({ name }, "[REDACTED_SECRET]", { expiresIn: "1h" });

  // Internally fetch a protected page using a privileged token
  const internalToken = jwt.sign(
    { /* redacted payload */ },
    "[REDACTED_SECRET]",
    { expiresIn: "30s" }
  );

  const flagRes = await fetch("http://127.0.0.1:3000/api/admin/flag", {
    headers: {
      Cookie: `auth=${internalToken}`,
      "x-trusted-user": "admin",
      "x-internal-access": "[REDACTED_INTERNAL_HEADER]",
      "User-Agent": "HeadlessChrome/115.0.0.0"
    }
  });

  const flagHtml = await flagRes.text();

  const htmlContent = `
    <html>
      <head>
        <meta http-equiv="Content-Security-Policy" content="style-src 'unsafe-inline'; default-src *">
        <style>${sanitizeCSS(theme)}</style>
      </head>
      <body>
        ${flagHtml}
      </body>
    </html>
  `;

  try {
    const browser = await puppeteer.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    const page = await browser.newPage();

    page.on("request", (req) => {
      const url = req.url();
      if (url.includes("webhook")) {
        console.log("[EXFIL] CSS exfil triggered!", url);
      }
    });

    await page.setContent(htmlContent);
    await new Promise(resolve => setTimeout(resolve, 2000));
    await browser.close();

    const response = NextResponse.json({ success: true, token });
    return response;
  } catch (err) {
    return NextResponse.json({ success: false, error: String(err) }, { status: 500 });
  }
}

function sanitizeCSS(input: string) {
  return input
    .split("\n")
    .filter(line =>
      !/expression|@import|@font-face/i.test(line)
    )
    .join("\n");
}
