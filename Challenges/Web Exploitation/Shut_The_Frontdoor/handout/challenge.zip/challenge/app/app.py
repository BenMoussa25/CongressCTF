from flask import Flask, request, redirect, url_for, send_from_directory, render_template
import os
import shutil
import uuid

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['SECRET_KEY'] = os.urandom(32)
app.config['ALLOWED_EXTENSIONS'] = {'zip', 'tar', 'gz', 'bz2', 'xz', 'tgz'}

# Create uploads directory if it doesn't exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

@app.route('/', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        if 'file' not in request.files:
            return redirect(request.url)
        
        file = request.files['file']
        if file.filename == '':
            return redirect(request.url)
        
        if file and allowed_file(file.filename):
            # Save original file
            filename = file.filename
            upload_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(upload_path)
            
            # Create unique extraction folder
            extract_folder = str(uuid.uuid4())
            extract_path = os.path.join(app.config['UPLOAD_FOLDER'], extract_folder)
            os.makedirs(extract_path, exist_ok=True)
            
            try:
                shutil.unpack_archive(upload_path, extract_path)
                # Get list of extracted files
                file_list = os.listdir(extract_path)
                return render_template('index.html', 
                                    success=True,
                                    files=file_list,
                                    folder=extract_folder)
            except Exception as e:
                return render_template('index.html', 
                                     error=f"Error extracting archive: {str(e)}")
        else:
            return render_template('index.html', 
                                error="Invalid file type. Supported formats: zip, tar, gz, bz2, xz")
    
    return render_template('index.html')

@app.route('/uploads/<path:filename>')
def serve_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)