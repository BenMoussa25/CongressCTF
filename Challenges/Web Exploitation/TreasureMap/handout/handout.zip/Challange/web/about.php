<?php include 'header.php'; ?>
    <main>
        <section>
            <h2>Our Mission</h2>
            <p>We are dedicated to helping pirates safely uncover hidden treasures without falling victim to cursed maps. Our mission is to:</p>
            <ul class="beautiful-list">
                <li>Protect pirate crews from dangerous treasure maps</li>
                <li>Provide accurate scanning of potential treasures</li>
                <li>Stay ahead of cursed map makers and their tricks</li>
                <li>Help pirates fill their treasure chests safely</li>
            </ul>
        </section>
        <section>
            <h2>Meet Our Crew</h2>
            <p>Our ship is crewed by the finest treasure hunters and map experts on the seven seas:</p>
            <ul class="beautiful-list">
                <li>Experienced treasure finders</li>
                <li>Map analysts</li>
                <li>Curse breakers</li>
                <li>Deck swabbers (they help too!)</li>
            </ul>
            <p>We work together to keep the treasure hunting community safe from cursed maps.</p>
        </section>
    </main>
<?php include 'footer.php'; ?>