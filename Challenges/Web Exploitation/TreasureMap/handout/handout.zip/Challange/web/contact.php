<?php include 'header.php'; ?>

<main>
    <section>
        <h2>Send a Parrot</h2>
        <p>Have questions or found a particularly tricky map? Send us a parrot with your message:</p>

        <h3>Parrot Message</h3>
        <p>Fill the form below to train your parrot:</p>

        <form action="contact.php" method="post" class="modern-contact-form">
            <div class="form-group">
                <label for="name">Your Pirate Name</label>
                <input type="text" id="name" name="name" required>
            </div>

            <div class="form-group">
                <label for="email">Your Ship</label>
                <input type="email" id="email" name="email" required>
            </div>

            <div class="form-group">
                <label for="message">Parrot Message</label>
                <textarea id="message" name="message" rows="5" required></textarea>
            </div>

            <div class="form-group">
                <button type="submit">Release Parrot</button>
            </div>
        </form>
    </section>
</main>

<?php include 'footer.php'; ?>