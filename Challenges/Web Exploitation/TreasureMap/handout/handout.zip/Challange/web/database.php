<?php include 'header.php'; ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <main>
        <section>
            <h2>Why We Share Our Treasure Logs</h2>
            <p>In the spirit of pirate brotherhood, we share our treasure logs with fellow seekers:</p>
            <ul class="beautiful-list">
                <li>Transparency: Know what treasures and curses we've encountered</li>
                <li>Education: Learn to recognize dangerous maps yourself</li>
                <li>Community: Contribute your own findings to help others</li>
            </ul>
        </section>
        <section>
            <h2>Treasure Logs</h2>
            <ul>
                <?php
                $treasureLogs = "treasure_logs";
                $logBooks = scandir($treasureLogs);
                
                foreach ($logBooks as $log) {
                    if ($log != "." && $log != "..") {
                        echo "<li class='database-card'>
                                <i class='database-icon fa fa-book'></i>
                                <a class='database-link' href='$treasureLogs/$log' target='_blank'>$log</a>
                              </li>";
                    }
                }
                ?>
            </ul>
        </section>
    </main>
<?php include 'footer.php'; ?>