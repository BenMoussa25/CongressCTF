<footer>
        &copy; <?php echo date("Y"); ?> Pirate Treasure Scanner | <a href="privacy.php">Captain's Orders</a> | <a href="contact.php">Send a Parrot</a>
    </footer>
</body>
</html>