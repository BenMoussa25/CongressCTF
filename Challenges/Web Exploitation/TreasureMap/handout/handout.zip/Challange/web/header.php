<!DOCTYPE html>
<html>
<head>
    <title>Pirate Treasure Scanner</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Pirata+One&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <div class="header-content">
            <i class="virus-icon fa fa-map"></i>
            <h1>Pirate <span class="cyber-text">Treasure Scanner</span></h1>
        </div>
        <div class="cyber-graphics">
            <i class="fa fa-anchor"></i>
            <i class="fa fa-treasure-chest"></i>
            <i class="fa fa-ship"></i>
        </div>
    </header>
    <nav>
        <ul>
            <li><a href="index.php">Ship</a></li>
            <li><a href="database.php">Treasure Logs</a></li>
            <li><a href="about.php">Crew</a></li>
        </ul>
    </nav>