<?php include 'header.php'; ?>
<main>
    <section>
        <p>
            Welcome to the Pirate Treasure Scanner! This service allows you to upload a single <strong>.tar.gz</strong> treasure map, which our server will examine for hidden treasures. We'll provide you with a percentage indicating how certain we are that treasure is hidden within the map.
        </p>
        <p>
            Why scan your maps? Many pirate maps contain dangerous traps or cursed treasures that could harm your ship and crew. By using our scanner, you can safely identify which maps are worth pursuing and which to throw overboard!
        </p>
        <p>
            So hoist the sails and scan your maps with our Pirate Treasure Scanner to safely uncover hidden riches without walking the plank!
        </p>
    </section>
    <section>
        <h2>Scan for Treasure</h2>
        <div class="upload-form">
            <form action="upload.php" method="post" enctype="multipart/form-data">
                <label for="treasureMap">Choose a treasure map to upload:</label>
                <input type="file" name="treasureMap" id="treasureMap" accept=".tar.gz">
                <button type="submit" class="upload-button">Scan Map</button>
            </form>
        </div>
    </section>
</main>
<?php include 'footer.php'; ?>