<?php include 'header.php'; ?>

<main>
    <section>
        <h2>Captain's Orders</h2>
        <p>These be the rules of our ship. By coming aboard, you agree to follow them:</p>

        <h3>What We Collect</h3>
        <p>We may collect information about the treasure maps you bring aboard, including their markings and any notes you provide. We use this only to improve our treasure finding services.</p>

        <h3>How We Use Your Information</h3>
        <p>We use the information we collect to:</p>
        <ul>
            <li>Scan your maps for hidden treasures</li>
            <li>Improve our treasure finding skills</li>
            <li>Keep our ship in good working order</li>
        </ul>

        <h3>Security Measures</h3>
        <p>We keep your maps locked in the captain's cabin to prevent unauthorized access.</p>

        <h3>Contact Us</h3>
        <p>If you have questions about these orders, <a href="contact.php">send a parrot</a>.</p>
    </section>
</main>

<?php include 'footer.php'; ?>