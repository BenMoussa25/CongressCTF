<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $treasureChest = "/tmp/";
    $targetTreasure = $treasureChest . basename($_FILES["treasureMap"]["name"]);
    $mapType = pathinfo($_FILES["treasureMap"]["name"], PATHINFO_EXTENSION);
    $allowedMaps = array('gz');

    echo '<div id="log"></div>';

    if (!in_array($mapType, $allowedMaps)) {
        echo "Arrr! Only .tar.gz treasure maps be allowed here!";
        exit();
    }

    ob_start();

    function addLog($message) {
        echo "<script>document.getElementById('log').innerHTML += '$message<br>';</script>";
        ob_flush();
        flush();
    }

    addLog("Unfurlin' the map...");
    
    if (move_uploaded_file($_FILES["treasureMap"]["tmp_name"], $targetTreasure)) {
        addLog("The map " . htmlspecialchars(basename($_FILES["treasureMap"]["name"])) . " has been stowed in the hold.");

        if ($mapType === 'gz') {
            addLog("Searchin' for treasure...");

            // Execute python treasure finder
            exec("python3 /usr/find_hidden_treasure.py " . escapeshellarg($targetTreasure), $output, $result);

            if ($result === 0) {
                addLog("Treasure hunt successful!");
            } else {
                addLog("Blimey! The treasure hunt failed!");
            }

            unlink($targetTreasure);
            addLog("Cleaning the deck...");

            addLog("Done.");

        }
    } else {
        addLog("Shiver me timbers! There was an error stowing your map!");
    }

    ob_end_flush();
}
?>

<link rel="stylesheet" type="text/css" href="styles.css">
<a href="index.php" class="back-button">Back to Ship</a>