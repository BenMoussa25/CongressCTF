from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
import requests
import uuid
import re
import os
import bot

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///styles.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

flag = os.environ.get("FLAG") or "CyberSphere{fake_flag}" 

def bad(css_content):
    for keyword in ['~','*','^','$','[',']','background','url','@','import','http']:
        if keyword in css_content:
            return True
    return False

class Style(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    uuid = db.Column(db.String(36), unique=True, nullable=False)
    css_url = db.Column(db.String(255), nullable=False)

with app.app_context():
    db.create_all()


@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

# Report to me if there are issues
@app.route('/report/<uuid>', methods=['GET'])
def report(uuid):
    style = Style.query.filter_by(uuid=uuid).first()
    if style:
        status = bot.visit(uuid)
        if status:
            return "Reported!", 200
        else:
            return "Something went wrong.. contact author!", 500
    else:
        return "Style not found", 404

@app.route('/admin_preview/<uuid>', methods=['GET'])
def admin_preview(uuid):
    if request.remote_addr == '127.0.0.1' or request.remote_addr == '::1':
        style = Style.query.filter_by(uuid=uuid).first()
        if style:
            css_url = style.css_url
            
            try:
                response = requests.get(css_url)
                response.raise_for_status()
                css_content = response.text
                
                if bad(css_content) or len(css_content) > 100:
                    # begone bad css
                    db.session.delete(style)  
                    db.session.commit()             
                    return "Bad boy!", 500
                
                return render_template('admin_preview.html', css_url=css_url, flag=flag)
            except requests.exceptions.RequestException as e:
                return "Error", 500
        else:
            return "Style not found", 404
    else:
        return "Access denied", 403 

@app.route('/add', methods=['POST'])
def add_style():
    css_url = request.form['css_url']
    
    if not re.match(r'https?://', css_url):
        return redirect(url_for('index'))  

    try:
        response = requests.head(css_url)
        response.raise_for_status()
        
        unique_id = str(uuid.uuid4())
        
        new_style = Style(uuid=unique_id, css_url=css_url)
        db.session.add(new_style)
        db.session.commit()
        
        return redirect(url_for('preview', uuid=unique_id))
    except requests.exceptions.RequestException as e:
        return "Nuh uh"

@app.route('/preview/<uuid>', methods=['GET'])
def preview(uuid):

    style = Style.query.filter_by(uuid=uuid).first()
    if style:
        css_url = style.css_url
        
        try:
            response = requests.get(css_url)
            response.raise_for_status()
            css_content = response.text
            
            if bad(css_content) or len(css_content) > 100:
                # begone bad css
                db.session.delete(style)  
                db.session.commit()             
                return "Bad boy!", 500
            
            return render_template('preview.html', css_url=css_url,id=uuid)
        except requests.exceptions.RequestException as e:
            return "Error", 500
    else:
        return "Style not found", 404

if __name__ == '__main__':
    app.run(host="0.0.0.0",port="80",debug=False)
