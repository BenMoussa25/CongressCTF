const express = require('express');
const path = require('path');
const fs = require('fs');
const session = require('express-session');
const { v4: uuidv4 } = require('uuid');
const crypto = require('crypto');
const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

var token = crypto.randomBytes(48).toString('hex'); console.log(token);

app.use(session({
    secret: token,
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }
}));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

const uploadDir = path.join(__dirname, 'uploads');

if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
}


let admin_id = uuidv4()

let users = {
    [admin_id]: { password: "admin", role: "admin" }
};

console.log(users)

let documents = [
    "silly-cars-list.txt",
    "Ret3i-Secret-Hitman-List.txt",
];

function merge(target, source) {
    for (const attr in source) {
      if (typeof target[attr] === "object" && typeof source[attr] === "object") {
        merge(target[attr], source[attr]);
      } else {
        target[attr] = source[attr];
      }
    }
    return target;
  }

function authenticate(req, res, next) {
    if (!req.session.userId) {
        return res.redirect('/');
    }
    next();
}

function isAdmin(req, res, next) {
    let id = req.session.userId
    const user = users[id]
    if (!user || user.role !== 'admin') {
        return res.redirect('/welcome')
    }
    next();
}

app.get('/', (req, res) => {
    res.render('login');
});

app.get('/register', (req, res) => {
    res.render('register');
});

app.post('/register', (req, res) => {
    const id = uuidv4() ; 
    const { password } = req.body;
    
    if (!password) {
        return res.status(400).json({ error: 'Password is required' });
    }

    let user = { 
        [id]: { password: password, role: "guest" }
    }

    merge(users,user);

    return res.json({ "id":id })
});

app.post('/login', (req, res) => {
    const { id, password } = req.body;
    let user = users[id]
    if (user) {
        if (user.password === password) {
            req.session.userId = [id];
            req.session.role = user.role;
            
            if (user.role === 'guest') {
                return res.json({ "Success":true, "role": "guest" })
            } else if (user.role === 'admin') {
                return res.json({ "Success":true, "role": "admin" })
            }            
        } else {
            return res.json({ "Success":false });
        }
    } else {
        return res.json({ "Success":false });
    }

});

app.get('/welcome', authenticate, (req, res) => {
    res.render('welcome');
});

app.get('/dashboard', authenticate, isAdmin, (req, res) => {
    res.render('dashboard', { documents });
});

app.get('/download/:filename', authenticate, isAdmin, (req, res) => {
    const filename = req.params.filename;
    const filePath = path.join(uploadDir, filename);
    
    if (fs.existsSync(filePath)) {
        res.download(filePath);
    } else {
        res.status(404).send('File not found');
    }
});

app.post('/update-password', authenticate, (req, res) => {
    const id = req.session.userId;
    const { password }  = req.body;

    if (!password) {
        return res.status(400).json({ error: 'Password required' });
    }

    merge(users[id], password);

    res.json({ success: true });
});


app.get('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            return res.status(500).send('Could not log out');
        }
        res.redirect('/');
    });
});

app.listen(PORT,'0.0.0.0', () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});